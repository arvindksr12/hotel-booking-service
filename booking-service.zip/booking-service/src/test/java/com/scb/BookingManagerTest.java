package com.scb;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class BookingManagerTest {

    private BookingManager bookingManager;

    @BeforeEach
    public void init() {
        bookingManager = new BookingManager();
    }

    @Test
    public void test_bookRoom() throws InterruptedException {
        MultiUserThread thread1 = new MultiUserThread(new BookingDetail("A", 2, new Date()));
        MultiUserThread thread2 = new MultiUserThread(new BookingDetail("B", 2, new Date()));

        Thread t1 = new Thread(thread1);
        Thread t2 = new Thread(thread2);

        t1.start();
        t2.start();

        t1.join();
        t2.join();
    }

    @Test
    public void test_availableRoom()  {

        List<BookingDetail> rooms = new ArrayList<>();
        BookingDetail bookingDetailA = new BookingDetail("A", 2, new Date());
        BookingDetail bookingDetailB = new BookingDetail("B", 2, new Date());

        rooms.add(bookingDetailA);
        rooms.add(bookingDetailB);

        List<BookingDetail>  bookingDetails = rooms.stream().filter(r -> r.getBookingDate().equals(new Date())).collect(Collectors.toList());
        long noOfRoom =  bookingManager.availableRoom(new Date());
       // assertEquals(bookingDetails.size(), noOfRoom);

    }

    @Test
    public void test_findAllBookingByUser() {
        List<BookingDetail> rooms = new ArrayList<>();
        BookingDetail bookingDetailA = new BookingDetail("A", 2, new Date());
        BookingDetail bookingDetailB = new BookingDetail("B", 2, new Date());

        rooms.add(bookingDetailA);
        rooms.add(bookingDetailB);

        long bookingDetails = rooms.stream().filter(r -> r.getGuestName().equalsIgnoreCase("A")).mapToLong(BookingDetail :: getNoOfRoom).sum();


        long noOfRooms = bookingManager.findAllBookingByUser("A");
      //  assertEquals(noOfRooms, bookingDetails);

    }
}
