package com.scb;

public class MultiUserThread implements Runnable {
    BookingDetail room;
    BookingManager bookingManager = new BookingManager();
    public MultiUserThread(BookingDetail room) {
        this.room = room;
    }
    @Override
    public void run() {
        bookingManager.bookRoom(room);
    }
}
