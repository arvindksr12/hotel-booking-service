package com.scb;

import java.util.Date;

public class BookingDetail {

    private String guestName;
    private int noOfRoom;
    Date bookingDate;

    public BookingDetail(String guestName, int noOfRoom, Date bookingDate) {
        this.guestName = guestName;
        this.noOfRoom = noOfRoom;
        this.bookingDate = bookingDate;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public int getNoOfRoom() {
        return noOfRoom;
    }

    public void setNoOfRoom(int noOfRoom) {
        this.noOfRoom = noOfRoom;
    }

    public Date getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(Date bookingDate) {
        this.bookingDate = bookingDate;
    }
}
