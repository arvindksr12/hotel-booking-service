package com.scb;

import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class BookingManager {
    int availableRoom = 5;
    List<BookingDetail> rooms = new CopyOnWriteArrayList<>();
    public synchronized void bookRoom(BookingDetail room) {
        if (availableRoom >= room.getNoOfRoom() && room.getNoOfRoom() > 0) {
            System.out.println("Hi "+ room.getGuestName() + " : "+ room.getNoOfRoom() +" rooms booked successfully "+room.getNoOfRoom());
            availableRoom = availableRoom - room.getNoOfRoom();
            rooms.add(new BookingDetail(room.getGuestName(),room.getNoOfRoom(),room.getBookingDate()));
        } else {
           System.out.println("Hi "+ room.getGuestName()+" : Rooms Not Available");
        }
    }

    public long availableRoom(Date date)  {
        if (rooms != null && rooms.size() > 0) {
            return rooms.stream().filter( r-> r.getBookingDate().equals(date)).count();
        }
        return 0;
    }
    public long findAllBookingByUser(String user) {
        if (rooms != null && rooms.size() > 0) {
            return rooms.stream().filter(r -> r.getGuestName().equalsIgnoreCase(user)).mapToLong(BookingDetail :: getNoOfRoom).sum();
        }
        return 0;
    }
}
